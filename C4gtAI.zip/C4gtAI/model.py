
from transformers import pipeline

# Load grammar correction pipeline
grammar_corrector = pipeline("text2text-generation", model="vennify/t5-base-grammar-correction")

def correct_grammar(text: str) -> str:
    result = grammar_corrector(text)
    return result[0]['generated_text']
