import requests

data = {
    "sentence": "He go to school every day."
}

response = requests.post("http://localhost:8000/grammar", json=data)
print(response.json())  # Output: {"corrected": "He goes to school every day."}
