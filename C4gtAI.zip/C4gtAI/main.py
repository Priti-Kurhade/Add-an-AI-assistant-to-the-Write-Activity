from fastapi import FastAPI
from pydantic import BaseModel
from model import correct_grammar

app = FastAPI(title="Write Activity AI Assistant")

class TextInput(BaseModel):
    sentence: str

class TextOutput(BaseModel):
    corrected: str

@app.post("/grammar", response_model=TextOutput)
def grammar_correction(data: TextInput):
    corrected = correct_grammar(data.sentence)
    return {"corrected": corrected}
